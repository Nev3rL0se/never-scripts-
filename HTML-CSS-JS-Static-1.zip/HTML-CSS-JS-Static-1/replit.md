# Lua Script Hosting Portal

## Overview

This is a simple web application that allows users to upload Lua scripts and host them at accessible URLs. The application consists of a password-protected portal where authenticated users can upload `.lua` files, which are then stored on the server and made available via unique URLs.

**Core Features:**
- Secret code authentication gate
- Lua file upload functionality
- Script hosting with clean URLs (`/scripts/{script-name}`)
- Simple single-page interface with vanilla HTML/CSS/JavaScript

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Technology:** Vanilla HTML, CSS, and JavaScript (no framework)
- **Design Pattern:** Single-page application with container-based view switching
- **Views:** Three distinct containers managed via JavaScript:
  1. Authentication form
  2. Script creator/upload form
  3. Success confirmation with script URL

### Backend Architecture
- **Runtime:** Node.js with Express.js (v5.x)
- **Server Entry Point:** `script.js`
- **Port:** 5000
- **Design Pattern:** Simple REST API with static file serving

### API Endpoints
| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/` | Serves main HTML page |
| GET | `/style.css` | Serves stylesheet |
| POST | `/create` | Handles Lua file upload (multipart form) |
| GET | `/scripts/:name` | Serves hosted Lua scripts as plain text |

### File Upload Handling
- **Library:** Multer with memory storage
- **Validation:** Accepts `.lua` files only (client-side)
- **Naming:** Script names are sanitized (alphanumeric and hyphens, lowercase)
- **Storage Location:** `./scripts/` directory (auto-created on startup)

### Data Storage
- **Type:** File-based storage (no database)
- **Location:** Scripts stored as `.lua` files in the `scripts/` directory
- **Note:** If persistence or querying capabilities are needed, consider adding a database layer

### Authentication
- **Current Implementation:** Client-side secret code check (visible in frontend JavaScript)
- **Security Consideration:** This is not secure for production use; consider implementing server-side authentication if needed

## External Dependencies

### NPM Packages
| Package | Version | Purpose |
|---------|---------|---------|
| express | ^5.2.1 | Web server framework |
| multer | ^2.0.2 | Multipart form data handling (file uploads) |
| fs-extra | ^11.3.3 | Enhanced file system operations |

### Infrastructure Requirements
- Node.js runtime environment
- File system access for script storage
- No external services or APIs required