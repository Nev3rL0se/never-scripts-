const express = require('express');
const multer = require('multer');
const fs = require('fs-extra');
const path = require('path');

const app = express();
const port = 5000;

// Path configuration
const SCRIPTS_DIR = path.join(__dirname, 'scripts');
const PUBLIC_DIR = path.join(__dirname, 'public');

// Ensure directories exist
fs.ensureDirSync(SCRIPTS_DIR);
fs.ensureDirSync(PUBLIC_DIR);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(PUBLIC_DIR));

// Serve index.html as fallback for the root
app.get('/', (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

const storage = multer.memoryStorage();
const upload = multer({ 
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 } 
});

app.post('/create', upload.single('luaFile'), async (req, res) => {
    try {
        if (!req.file || !req.body.name) {
            return res.status(400).json({ error: 'Missing file or name' });
        }

        const name = req.body.name.replace(/[^a-z0-9-]/gi, '_').toLowerCase();
        const content = req.file.buffer.toString('utf8');
        
        await fs.writeFile(path.join(SCRIPTS_DIR, name + '.lua'), content);
        
        const host = req.get('host');
        const protocol = req.headers['x-forwarded-proto'] || 'http';
        const url = `${protocol}://${host}/scripts/${name}`;
        
        res.json({ url: url });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/scripts/:name', async (req, res) => {
    try {
        const filePath = path.join(SCRIPTS_DIR, req.params.name + '.lua');
        if (await fs.pathExists(filePath)) {
            const content = await fs.readFile(filePath, 'utf8');
            res.setHeader('Content-Type', 'text/plain');
            res.send(content);
        } else {
            res.status(404).send('Script not found');
        }
    } catch (err) {
        res.status(500).send('Error reading script');
    }
});

app.listen(port, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${port}`);
});
